import wfdb
import numpy as np
import pandas as pd

from glob import glob
import argparse
import os


def save_dataframe(df, filepath):
    if filepath.endswith('.csv'):
        df.to_csv(filepath, index=False)
    elif filepath.endswith('.pkl') or filepath.endswith('.pickle'):
        df.to_pickle(filepath)
    else:
        raise ValueError(f"Unsupported file extension in '{filepath}'. Use .csv or .pkl/.pickle.")


def load_dataframe(filepath):
    if filepath.endswith('.csv'):
        return pd.read_csv(filepath)
    elif filepath.endswith('.pkl') or filepath.endswith('.pickle'):
        return pd.read_pickle(filepath)
    else:
        raise ValueError(f"Unsupported file extension in '{filepath}'. Use .csv or .pkl/.pickle.")


def gen_reference_csv(data_dir, reference_file):
    if not os.path.exists(reference_file):
        recordpaths = glob(os.path.join(data_dir, '*.hea'))
        results = []
        for recordpath in recordpaths:
            patient_id = recordpath.split('/')[-1][:-4]
            _, meta_data = wfdb.rdsamp(recordpath[:-4])
            sample_rate = meta_data['fs']
            signal_len = meta_data['sig_len']
            age = meta_data['comments'][0]
            sex = meta_data['comments'][1]
            dx = meta_data['comments'][2]
            age = age[5:] if age.startswith('Age: ') else np.NaN
            sex = sex[5:] if sex.startswith('Sex: ') else 'Unknown'
            dx = dx[4:] if dx.startswith('Dx: ') else ''
            results.append([patient_id, sample_rate, signal_len, age, sex, dx])
        df = pd.DataFrame(data=results, columns=['patient_id', 'sample_rate', 'signal_len', 'age', 'sex', 'dx'])
        df.sort_values('patient_id', inplace=True)
        save_dataframe(df, reference_file)


def gen_label_csv(label_file, reference_file, dx_dict, classes):
    if not os.path.exists(label_file):
        results = []
        df_reference = load_dataframe(reference_file)
        for _, row in df_reference.iterrows():
            patient_id = row['patient_id']
            dxs = [dx_dict.get(code.strip(), '') for code in str(row['dx']).split(',')]
            labels = [0] * len(classes)
            for idx, label in enumerate(classes):
                if label in dxs:
                    labels[idx] = 1
            results.append([patient_id] + labels)
        df = pd.DataFrame(data=results, columns=['patient_id'] + classes)
        n = len(df)
        folds = np.zeros(n, dtype=np.int8)
        for i in range(10):
            start = int(n * i / 10)
            end = int(n * (i + 1) / 10)
            folds[start:end] = i + 1
        df['fold'] = np.random.permutation(folds)
        df['keep'] = df[classes].sum(axis=1)
        df = df[df['keep'] > 0]
        df.drop(columns=['keep'], inplace=True)
        save_dataframe(df, label_file)


if __name__ == "__main__":
    leads = ['I', 'II', 'III', 'aVR', 'aVL', 'aVF', 'V1', 'V2', 'V3', 'V4', 'V5', 'V6']
    dx_dict = {
        '426783006': 'SNR',
        '164889003': 'AF',
        '270492004': 'IAVB',
        '164909002': 'LBBB',
        '713427006': 'RBBB',
        '59118001': 'RBBB',
        '284470004': 'PAC',
        '63593006': 'PAC',
        '164884008': 'PVC',
        '429622005': 'STD',
        '164931005': 'STE',
    }
    classes = ['SNR', 'AF', 'IAVB', 'LBBB', 'RBBB', 'PAC', 'PVC', 'STD', 'STE']
    parser = argparse.ArgumentParser()
    parser.add_argument('--data-dir', type=str, default='data/CPSC', help='Directory to dataset')
    parser.add_argument('--file-format', type=str, default='csv', choices=['csv', 'pkl', 'pickle'], help='File format for output files')
    args = parser.parse_args()
    data_dir = args.data_dir
    ext = '.pkl' if args.file_format in ['pkl', 'pickle'] else '.csv'
    reference_file = os.path.join(data_dir, f'reference{ext}')
    label_file = os.path.join(data_dir, f'labels{ext}')
    gen_reference_csv(data_dir, reference_file)
    gen_label_csv(label_file, reference_file, dx_dict, classes)
